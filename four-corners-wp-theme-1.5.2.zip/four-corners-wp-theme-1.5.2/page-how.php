<?php /* Template Name: How it works */ ?>

<?php get_header(); ?>
<div id="page"></div>
<?php get_footer(); ?>