<?php /* Template Name: Default */ ?>

<?php get_header(); ?>
<div id="app"></div>
<?php get_footer(); ?>