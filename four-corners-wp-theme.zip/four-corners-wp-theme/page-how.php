<?php /* Template Name: How it works */ ?>

<?php get_header(); ?>
<div id="app"></div>
<?php get_footer(); ?>