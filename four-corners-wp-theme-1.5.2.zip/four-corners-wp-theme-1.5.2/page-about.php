<?php /* Template Name: About */ ?>

<?php get_header(); ?>
<div id="page"></div>
<?php get_footer(); ?>