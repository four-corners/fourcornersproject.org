<?php /* Template Name: About */ ?>

<?php get_header(); ?>
<div id="app"></div>
<?php get_footer(); ?>