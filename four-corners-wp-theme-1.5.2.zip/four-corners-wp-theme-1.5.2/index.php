<?php
/**
 * The main template file
 * Template Name: Home
 *
 * @package WordPress
 * @subpackage Four Corners
 * @since Four Corners 1.0
 */
 ?>
<?php get_header(); ?>
<div id="page"></div>
<?php get_footer(); ?>